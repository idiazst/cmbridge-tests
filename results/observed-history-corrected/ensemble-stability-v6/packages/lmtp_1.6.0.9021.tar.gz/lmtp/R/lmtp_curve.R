#' Pooled LMTP Curve Estimation
#'
#' @param data \[\code{data.frame}\]\cr
#'  A \code{data.frame} in wide format containing all necessary variables
#'  for the estimation problem. Must not be a \code{data.table}.
#' @param trt \[\code{character}\] or \[\code{list}\]\cr
#'  A vector containing the column names of treatment variables ordered by time.
#'  Or, a list of vectors, the same length as the number of time points of observation.
#'  Vectors should contain column names for the treatment variables at each time point. The list
#'  should be ordered following the time ordering of the model.
#' @param outcome \[\code{character}\]\cr
#'  The column name(s) of the outcome variable. In the case of time-to-event
#'  analysis or an outcome with sporadic measurement, a vector containing the columns names of intermediate outcome variables and the final
#'  outcome variable ordered by time. Only numeric values are allowed. If the outcome type
#'  is binary, data should be coded as 0 and 1.
#' @param baseline \[\code{character}\]\cr
#'  An optional vector containing the column names of baseline covariates to be
#'  included for adjustment at every time point.
#' @param time_vary \[\code{list}\]\cr
#'  A list the same length as the number of time points of observation with
#'  the column names for new time-varying covariates introduced at each time point. The list
#'  should be ordered following the time ordering of the model.
#' @param cens \[\code{character}\]\cr
#'  An optional vector of column names of censoring indicators the same
#'  length as the number of time points of observation. If missingness in the outcome is
#'  present or if time-to-event outcome, must be provided.
#' @param compete \[\code{character}\]\cr
#'  An optional vector of column names of competing risk indicators the same
#'  length as the number of time points of observation. Only used when \code{outcome_type = "survival"}.
#' @param shift \[\code{closure}\]\cr
#'  A two argument function that specifies how treatment variables should be shifted.
#'  See examples for how to specify shift functions for continuous, binary, and categorical exposures.
#' @param shifted \[\code{data.frame}\]\cr
#'  An optional data frame, the same as in \code{data}, but modified according
#'  to the treatment policy of interest. If specified, \code{shift} is ignored.
#' @param k \[\code{integer(1)}\]\cr
#'  An integer specifying how previous time points should be
#'  used for estimation at the given time point. Default is \code{Inf},
#'  all time points.
#' @param mtp \[\code{logical(1)}\]\cr
#'  Is the intervention of interest a modified treatment policy?
#'  Default is \code{TRUE}. If treatment variables are continuous this should be \code{TRUE}.
#' @param outcome_type \[\code{character(1)}\]\cr
#'  Outcome variable type (i.e., continuous, binomial, survival).
#' @param id \[\code{character(1)}\]\cr
#'  An optional column name containing cluster level identifiers.
#' @param bounds \[\code{numeric(2)}\]\cr
#'  An optional, ordered vector of the bounds for a continuous outcomes. If \code{NULL},
#'  the bounds will be taken as the minimum and maximum of the observed data.
#'  Should be left as \code{NULL} if the outcome type is binary.
#' @param learners_outcome \[\code{character}\]\cr A vector of \code{SuperLearner} algorithms for estimation
#'  of the outcome regression. Default is \code{"glm"}.
#' @param learners_trt \[\code{character}\]\cr A vector of \code{SuperLearner} algorithms for estimation
#'  of the outcome regression. Default is \code{"glm"}.
#'  \bold{Only include candidate learners capable of binary classification}.
#' @param folds The number of outer cross-fitting folds, or a list of folds
#'  with `training_set` and `validation_set` wide-row indices. Validation sets
#'  must partition the data and clusters must stay intact. `folds = 1` uses
#'  the full data for fitting and evaluation; it does not cross-fit.
#' @param learner_folds An optional list with one integer fold-label vector per
#'  outer fold, in that fold's training-row order. The same labels are used for
#'  treatment and outcome learner CV. Repeated records from a cluster must have
#'  the same label. Only labels represented in each fit's eligible rows are used.
#' @param weights \[\code{numeric(nrow(data))}\]\cr
#'  An optional vector containing sampling weights.
#' @param control \[\code{list()}\]\cr
#'  Output of \code{lmtp_control()}.
#'
#' @param estimator Either `"sdr"` (the default) or `"tmle"`. Both pool initial
#'  regressions across outcome times by recursive depth. TMLE uses a separate
#'  held-out logistic fluctuation for each outcome time and regression time.
#'
#' @details
#' TMLE completes its initial nuisance recursion entirely on the outer training
#' set before targeting the validation fold. Targeted validation responses never
#' become responses for a later initial nuisance fit. Its point estimate is the
#' mean of the targeted first regression, rather than an augmented SDR mean.
#' SDR cross-fits the training pseudo-outcome weights again inside each outer
#' training set. The optional isotonic pseudo-outcome calibration applies only
#' to SDR. Survival estimates retain the existing monotonicity projection;
#' `unprojected_estimates` records the values before projection.
#' If inner labels are not supplied, a common inner split is generated using
#' the larger of the two learner fold counts (at least two). Supplied labels
#' override those counts. Store and reuse the returned `folds` and `learner_folds`
#' to coordinate another nuisance-estimation package. Continuous bridge responses
#' must use `outcome_type = "continuous"` with appropriate common `bounds`.
#' The bridge and its adjoint correction are not implemented by this function.
#'
#' ## Should \code{mtp = TRUE}?
#' A modified treatment policy (MTP) is an intervention that depends
#' on the natural value of the exposure (the value that the treatment would have taken under no intervention).
#' This differs from other causal effects,
#' such as the average treatment effect (ATE), where an exposure would be increased (or decreased) deterministically.
#' \bold{If your intervention of interest adds, subtracts, or multiplies the observed treatment values
#' by some amount, use \code{mtp = TRUE}}.
#'
#' @return A list of class \code{lmtp_curve} containing the following components:
#'
#' \item{estimator}{The estimator used: "SDR curve" or "TMLE curve".}
#' \item{estimates}{The estimated population LMTP effects as \code{ife} objects.}
#' \item{shift}{The shift function specifying the treatment policy of interest.}
#' \item{outcome_reg}{A list of length Tau, where each index, t, is a n x t + 1 matrix of outcome regression predictions.}
#' \item{density_ratios}{An n x Tau matrix of the estimated, non-cumulative, density ratios.}
#' \item{sporadic_weights}{An n x Tau matrix of the estimated, non-cumulative, sporadic measurment inverse probability weights.}
#' \item{fits_m}{A list the same length as \code{folds}, containing the fits at each time-point
#'  for each fold for the outcome regression.}
#' \item{fits_r}{A list the same length as \code{folds}, containing the fits at each time-point
#' for each fold of density ratio estimation.}
#' \item{fits_sporadic}{A list the same length as \code{folds}, containing the fits at each time-point for the probability of an observation being measured.}
#' \item{outcome_type}{The outcome variable type.}
#' \item{folds, learner_folds}{The outer and inner sample splits actually used.}
#' \item{targeting}{For TMLE, per-fold and per-outcome fluctuation coefficients and weighted residual scores.}
#' \item{unprojected_estimates}{Point estimates before the survival monotonicity projection.}
#'
#' @export
#'
#' @example inst/examples/curve-ex.R
lmtp_curve <- function(data, trt, outcome, baseline = NULL, time_vary = NULL,
                       cens = NULL, compete = NULL, shift = NULL, shifted = NULL,
                       k = Inf, mtp = TRUE,
                       outcome_type = c("binomial", "continuous", "survival"),
                       id = NULL,
                       learners_outcome = "glm",
                       learners_trt = "glm",
                       folds = 10,
                       weights = NULL,
                       control = lmtp_control(),
                       estimator = c("sdr", "tmle"), bounds = NULL,
                       learner_folds = NULL) {

  estimator <- match.arg(estimator)
  assert_not_data_table(data)
  assert_outcome_types(data, outcome, match.arg(outcome_type))

  # Check if the treatment is continuous and warn if MTP is false
  check_trt_type(data, unlist(trt), mtp)

  task <- LmtpTask$new(
    data = data,
    shifted = make_shifted(data, trt, cens, shift, shifted),
    A = trt,
    Y = outcome,
    L = time_vary,
    W = baseline,
    C = cens,
    D = compete,
    k = k, id = id,
    outcome_type = match.arg(outcome_type),
    folds = folds, weights = weights, bounds = bounds, learner_folds = learner_folds
  )

  prepare_curve_splits(task, control)

  # Create progress bar object
  pb <- progressr::progressor(task$tau*length(task$folds)*3)

  # Estimate density ratios
  ratios <- cf_r(task, learners_trt, mtp, control, pb)
  sporadic_weights <- cf_sporadic(task, learners_trt, control, pb)

  # Estimate outcome regression
  curve <- cf_curve(task, ratios$ratios, sporadic_weights$weights, learners_outcome, control, pb, estimator, learners_trt, mtp)

  influence_functions <- curve$influence_functions
  shifted <- curve$shifted

  if(estimator == "sdr" && control$.isotonic_constraint && task$outcome_type == "binomial") {
    iso <- cf_isotonic(task, ratios, sporadic_weights, curve)

    influence_functions <- iso$influence_functions
    shifted <- iso$shifted
  }

  theta_curve(
    task = task,
    estimator = estimator,
    targeting = curve$targeting,
    influence_functions = influence_functions,
    sequential_regressions = shifted,
    density_ratios = ratios$ratios,
    sporadic_weights = sporadic_weights$weights,
    fits_m = curve$fits,
    fits_r = ratios$fits,
    fits_sporadic = sporadic_weights$fits,
    shift = deparse(substitute((shift)))
  )
}
